<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'u907549931_rw');//root
define('DB_PASSWORD', '9464685055');//9876543210
define('DB_HOST', 'mysql.hostinger.in');
define('DB_NAME', 'u907549931_rw');//nmsteg3s_quiztide_game


 
//define("GOOGLE_API_KEY", "AIzaSyAhqwrrjF6JEVvbj6cGvA1YCzmzDD8Y7DM");
 
// push notification flags
//define('PUSH_FLAG_CHATROOM', 1);
//define('PUSH_FLAG_USER', 2);
 
?>